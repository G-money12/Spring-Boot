package org.pgm.board01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Board01Application {

    public static void main(String[] args) {
        SpringApplication.run(Board01Application.class, args);
    }

}
